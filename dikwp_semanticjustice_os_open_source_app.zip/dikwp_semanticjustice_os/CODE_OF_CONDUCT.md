# Code of Conduct

This project is intended to support access to justice and accountable AI. Contributors should avoid harassment, discriminatory use, unauthorized processing of sensitive personal data, and any claim that the software replaces legal professionals.
