# Landing Page Copy

## DIKWP SemanticJustice OS

**Make legal reasoning visible before decisions are made.**

DIKWP SemanticJustice OS is an open-source semantic-space justice scaffold. It maps legal rules, evidence, facts, and stakeholder narratives into DIKWP graphs, then produces a human-review issue queue and plain-language explanation pack.

It helps legal aid teams and public institutions answer:

- Are the facts supported?
- Are due process safeguards visible?
- Is the proposed action aligned with the law's purpose?
- Are stakeholder misunderstandings, vulnerabilities, and fairness concerns visible?
- What should a human legal professional review next?

Not a verdict engine. Not legal advice. A transparent preparation layer for access to justice.
