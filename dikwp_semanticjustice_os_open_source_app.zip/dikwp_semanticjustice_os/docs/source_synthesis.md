# Source Synthesis

The system is inspired by the DIKWP semantic judicial reasoning direction: transform traditional legal judgment processes from conceptual-symbolic representation into DIKWP semantic graphs, and use DIKWP×DIKWP bidirectional mapping to integrate objective legal content with stakeholder cognition.

The system also inherits DIKWP-Mesh operational discipline: evidence and priors are separated; semantic registration comes before judgment; reliability is marked; residuals are retained; high-risk legal action requires human review.

The application intentionally avoids automated legal decisions. Its contribution is to make the semantic structure of legal reasoning visible, contestable, and reviewable.
