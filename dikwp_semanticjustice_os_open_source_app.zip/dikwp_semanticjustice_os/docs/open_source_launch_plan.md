# Open Source Launch Plan

1. Publish repository with README, NOTICE, CITATION.cff, and demo case.
2. Add a visible disclaimer: not legal advice, not verdict engine.
3. Tag release `v0.1.0`.
4. Publish a short article: "From Legal AI to Semantic Justice: DIKWP SemanticJustice OS".
5. Invite legal aid clinics and AI & law researchers to test with anonymized cases.
6. Add jurisdiction-specific policy packs only through legal expert review.
7. Build connectors with ProofLedger, AgentTrace, and MemoryLedger.
8. Later add multilingual plain-language explanation packs.
