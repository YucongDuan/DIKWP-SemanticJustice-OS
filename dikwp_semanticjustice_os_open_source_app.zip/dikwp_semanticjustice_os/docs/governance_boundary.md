# Governance Boundary

Allowed uses:

- intake preparation;
- legal aid triage;
- explanation support;
- evidence ledger organization;
- legal AI explainability research;
- public-sector transparency tooling;
- education and simulation.

Forbidden uses:

- automated verdict, sentencing, deportation, benefit denial, eviction, custody, detention, or enforcement;
- criminal risk scoring;
- covert surveillance;
- discrimination or targeting of protected groups;
- legal advice without qualified professional review;
- processing sensitive legal or personal data without consent and minimization;
- removal of action boundaries, residuals, or human-review gates.

Kill conditions:

- Current law or jurisdiction unknown;
- major factual disputes unresolved;
- due process safeguards absent;
- high-stakes outcome requested;
- evidence support below threshold;
- party vulnerability not considered;
- user attempts automated legal decision.
