from __future__ import annotations
import ast, json
from pathlib import Path
from typing import Dict, Any, List

FORBIDDEN_IMPORTS={"socket","requests","urllib","http","subprocess","os.system","paramiko","ftplib"}
FORBIDDEN_NAMES={"eval","exec","compile","__import__","popen","system","remove","unlink","rmdir"}


def audit_path(path: str | Path) -> Dict[str, Any]:
    p=Path(path)
    findings=[]
    for py in p.rglob("*.py"):
        text=py.read_text(encoding="utf-8")
        try:
            tree=ast.parse(text)
        except SyntaxError as e:
            findings.append({"file":str(py),"type":"syntax_error","detail":str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    name=alias.name.split('.')[0]
                    if name in FORBIDDEN_IMPORTS:
                        findings.append({"file":str(py),"type":"forbidden_import","detail":alias.name})
            if isinstance(node, ast.ImportFrom):
                mod=(node.module or "").split('.')[0]
                if mod in FORBIDDEN_IMPORTS:
                    findings.append({"file":str(py),"type":"forbidden_import","detail":node.module})
            if isinstance(node, ast.Call):
                func=node.func
                name=None
                if isinstance(func, ast.Name): name=func.id
                elif isinstance(func, ast.Attribute):
                    # Allow harmless stdlib helpers such as re.compile; block host-mutation attributes only.
                    name=func.attr if func.attr in {"popen","system","remove","unlink","rmdir"} else None
                if name in FORBIDDEN_NAMES:
                    findings.append({"file":str(py),"type":"forbidden_call","detail":name})
    return {"pass":not findings,"finding_count":len(findings),"findings":findings,"policy":"No network imports, subprocess, dynamic execution, host mutation, or enforcement helpers."}


def write_audit(path: str | Path, out: str | Path) -> Dict[str, Any]:
    result=audit_path(path)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result
