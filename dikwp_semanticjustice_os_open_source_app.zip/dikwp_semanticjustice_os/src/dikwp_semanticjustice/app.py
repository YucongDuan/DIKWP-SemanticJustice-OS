from __future__ import annotations
import json
try:
    import streamlit as st
except Exception:  # pragma: no cover
    st=None
from .analyzer import parse_case, analyze_case


def main():
    if st is None:
        raise RuntimeError("Install streamlit extra: pip install -e .[app]")
    st.title("DIKWP SemanticJustice OS")
    st.caption("Non-adjudicative legal semantic audit scaffold. Not legal advice.")
    raw=st.text_area("Paste case JSON", height=420)
    if st.button("Analyze") and raw.strip():
        case=parse_case(json.loads(raw))
        report=analyze_case(case)
        st.metric("Semantic Justice Score", report.semantic_justice_score)
        st.write("Decision", report.decision)
        st.json(report.to_dict())

if __name__ == "__main__":
    main()
