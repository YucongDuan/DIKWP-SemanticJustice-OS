# Security Policy

Report security concerns privately to project maintainers. Do not include real parties' personally identifiable information in public issues. Do not submit live case files unless properly anonymized and authorized.

This prototype is offline-first and does not include network calls by default.
