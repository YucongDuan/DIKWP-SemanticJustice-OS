# GitHub Release Draft: v0.1.0

DIKWP SemanticJustice OS v0.1.0 is the first public prototype of a semantic-space justice intake and audit scaffold.

Highlights:

- DIKWP normative legal graph;
- DIKWP stakeholder cognition graph;
- semantic alignment matrix;
- due process, evidence, proportionality, and purpose-alignment flags;
- legal review checklist;
- plain-language party explanation pack;
- offline-first CLI and optional Streamlit UI;
- no network calls and no automated adjudication.

Use cases: legal aid intake, administrative dispute preparation, legal AI explainability research, and public-sector transparency tooling.
