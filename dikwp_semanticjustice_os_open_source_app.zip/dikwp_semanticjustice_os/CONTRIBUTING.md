# Contributing

Contributions are welcome when they strengthen transparency, legal safety, accessibility, evidence custody, and explainability.

Preferred contributions:
- jurisdiction-specific legal schema packs prepared by qualified legal experts;
- multilingual legal term mapping;
- evidence ledger connectors;
- legal aid intake templates;
- fairness and due process checklists;
- evaluation benchmarks.

Do not submit code that enables automated adjudication, credential collection, covert surveillance, legal impersonation, evasion of legal process, or hidden data exfiltration.
