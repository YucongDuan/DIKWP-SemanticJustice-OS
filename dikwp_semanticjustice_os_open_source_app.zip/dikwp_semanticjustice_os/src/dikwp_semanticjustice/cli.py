from __future__ import annotations
import argparse, json
from pathlib import Path
from .analyzer import load_case, analyze_case
from .reports import write_outputs
from .static_audit import write_audit


def main(argv=None):
    parser=argparse.ArgumentParser(prog="semanticjustice", description="DIKWP SemanticJustice OS")
    sub=parser.add_subparsers(dest="cmd", required=True)
    a=sub.add_parser("analyze")
    a.add_argument("case_json")
    a.add_argument("--out", default="outputs/demo")
    s=sub.add_parser("static-audit")
    s.add_argument("src_path")
    s.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args=parser.parse_args(argv)
    if args.cmd=="analyze":
        case=load_case(args.case_json)
        report=analyze_case(case)
        write_outputs(report,args.out)
        print(json.dumps({"case_id":report.case_id,"decision":report.decision,"semantic_justice_score":report.semantic_justice_score,"issue_count":len(report.issues)}, ensure_ascii=False, indent=2))
    elif args.cmd=="static-audit":
        result=write_audit(args.src_path,args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
