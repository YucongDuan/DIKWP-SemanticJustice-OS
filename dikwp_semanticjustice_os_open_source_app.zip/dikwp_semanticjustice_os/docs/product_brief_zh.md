# DIKWP SemanticJustice OS 产品简报

**一句话定位：** 面向法律援助、行政争议、基层治理、智慧法院研究和法律 AI 可解释性的开源语义空间司法系统。

它不是自动判案工具，而是把法律规范、证据、事实和当事人理解全部映射到 DIKWP 语义空间，生成可审计的司法语义账本。系统输出的不是“谁赢谁输”，而是：哪些事实缺证据，哪些规则缺解释，哪些程序保障不可见，哪些当事人认知与法律目的之间存在语义鸿沟，哪些行动需要人类法律专业人员复核。

## 适用场景

- 法律援助初筛与案情整理；
- 行政处罚、医保、劳动、住房等高频民生纠纷的就医前/诉前整理；
- 智慧法院和司法 AI 研究；
- 律所或法务团队的证据账本与解释包；
- 公共政策执行中的比例原则、程序正义和当事人理解审计。

## 主要输出

- DIKWP normative graph；
- DIKWP stakeholder cognition graph；
- semantic alignment matrix；
- justice issue queue；
- legal review checklist；
- party explanation pack。

## 商业化路径

- 法律援助机构本地部署；
- 司法 AI 可解释性研究工具；
- 行政执法解释包生成；
- 律所证据账本 SaaS；
- DIKWP Semantic Justice 培训认证；
- 多语司法语义翻译插件；
- 与 ProofLedger、IntentGuard、AgentTrace 组成 DIKWP TrustOS for Law。
