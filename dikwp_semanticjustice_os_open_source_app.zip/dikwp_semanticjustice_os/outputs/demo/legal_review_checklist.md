# Legal Review Checklist

Case: Street vendor administrative penalty dispute (admin-demo-001)
Decision: human_legal_review_required
Semantic Justice Score: 0.6921

## Scores
- evidence_support: 1.0
- due_process_visibility: 0.75
- stakeholder_alignment: 0.3472
- purpose_alignment: 0.45
- equity_context: 0.75

## Issues for human review
- **MEDIUM / stakeholder_cognitive_gap**: Stakeholder S3 has goals or perceived injustice weakly connected to the visible legal-norm semantics. Recovery: prepare plain-language explanation and identify whether cognition gap reflects missing law, missing facts, mistranslation, or genuine injustice
- **HIGH / purpose_misalignment**: The proposed action is weakly aligned with visible stated legal purposes. Formal legality may not equal semantic justice. Recovery: state the legal purpose, public interest, proportionality rationale, and least-burdensome alternative
- **HIGH / proportionality_gap**: Proposed action appears severe but proportionality/equity semantics are not visible. Recovery: evaluate necessity, proportionality, less restrictive alternatives, and affected party circumstances

## Required checks
- Verify jurisdiction and current legal text.
- Verify evidence chain and admissibility.
- Verify due process: notice, hearing, reasons, appeal, representation.
- Verify proportionality and less-burdensome alternatives.
- Verify whether stakeholder cognition gap reflects misunderstanding, missing facts, translation, or actual injustice.
- Do not issue automated legal decision from this report.
