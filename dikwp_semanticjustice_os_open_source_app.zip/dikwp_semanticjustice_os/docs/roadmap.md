# Roadmap

## v0.2
- richer legal element extraction;
- multilingual legal term mapping;
- policy pack schema;
- claim-to-evidence alignment with ProofLedger.

## v0.3
- plain-language explanation evaluation;
- procedural fairness benchmark;
- stakeholder cognition comparison visualizations;
- legal aid workflow templates.

## v0.4
- jurisdiction adapters;
- RAG integration with source custody;
- privacy-preserving anonymization;
- human reviewer workflow.

## v1.0
- enterprise/legal-aid deployment pack;
- role-based access control;
- cryptographic evidence custody;
- independent evaluation benchmark.
