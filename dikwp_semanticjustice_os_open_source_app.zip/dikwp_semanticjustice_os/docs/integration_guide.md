# Integration Guide

## Inputs

The current prototype accepts JSON case profiles. Future connectors can map from:

- legal aid intake forms;
- court e-filing metadata;
- administrative penalty notices;
- public policy rulebooks;
- evidence management systems;
- RAG legal retrieval systems.

## Outputs

Outputs are JSON, CSV, and Markdown. They can be passed to:

- legal aid case management;
- legal professional review;
- ProofLedger claim-to-evidence audit;
- AgentTrace runtime review;
- public-sector explanation portals.

## Minimal human workflow

1. Intake worker enters facts and documents.
2. System generates issue queue.
3. Lawyer or qualified legal professional checks jurisdiction and law.
4. Party receives plain-language explanation pack.
5. Evidence and missing facts are collected.
6. No automated legal decision is made by the software.
