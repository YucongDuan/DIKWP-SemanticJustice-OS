from __future__ import annotations
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple
from .models import CaseInput, LegalNorm, EvidenceItem, Stakeholder, JusticeIssue, JusticeReport
from .dikwp import build_normative_graph, build_stakeholder_graph, DUE_PROCESS_TERMS, EQUITY_TERMS
from .text_utils import tokens, jaccard, keyword_hit, norm_text


LEGAL_ACTION_TERMS = ["penalty", "fine", "evict", "revoke", "deny", "detain", "deport", "sanction", "处罚", "罚款", "撤销", "驱逐", "拒绝", "拘留", "制裁"]
HIGH_STAKES_TERMS = ["custody", "criminal", "deport", "eviction", "benefits", "medical", "child", "刑事", "羁押", "驱逐", "住房", "儿童", "医疗", "低保"]


def parse_case(data: Dict[str, Any]) -> CaseInput:
    return CaseInput(
        case_id=data.get("case_id","case-unknown"),
        title=data.get("title","Untitled case"),
        jurisdiction=data.get("jurisdiction","unspecified"),
        case_type=data.get("case_type","unspecified"),
        facts=list(data.get("facts",[])),
        legal_norms=[LegalNorm(**n) for n in data.get("legal_norms",[])],
        evidence=[EvidenceItem(**e) for e in data.get("evidence",[])],
        stakeholders=[Stakeholder(**s) for s in data.get("stakeholders",[])],
        proposed_action=data.get("proposed_action",""),
        requested_output=data.get("requested_output","semantic_audit_only"),
    )


def load_case(path: str | Path) -> CaseInput:
    return parse_case(json.loads(Path(path).read_text(encoding="utf-8")))


def _score_evidence(case: CaseInput) -> Tuple[float,List[JusticeIssue]]:
    issues=[]
    claims=case.facts + [case.proposed_action]
    if not claims:
        return 0.2, [JusticeIssue("evidence-0","evidence_gap","medium","No facts supplied; cannot evaluate evidence support.")]
    supported=0
    ev_text=" ".join(e.text + " " + " ".join(e.supports) for e in case.evidence)
    for i,c in enumerate(claims):
        if not norm_text(c):
            continue
        if jaccard(tokens(c), tokens(ev_text)) > 0.04 or any(s in c for e in case.evidence for s in e.supports):
            supported += 1
        else:
            issues.append(JusticeIssue(f"evidence-gap-{i}","evidence_gap","medium",f"Claim appears weakly supported: {c[:180]}", evidence_ids=[e.evidence_id for e in case.evidence[:3]], recovery="add source, witness statement, record, citation, or mark as contested"))
    score=supported/max(1,len([c for c in claims if norm_text(c)]))
    return round(score,4), issues


def _score_due_process(case: CaseInput) -> Tuple[float,List[JusticeIssue]]:
    text=" ".join([n.text + " " + " ".join(n.safeguards) for n in case.legal_norms] + case.facts + [case.proposed_action])
    has_due=keyword_hit(text, DUE_PROCESS_TERMS)
    high=keyword_hit(text, LEGAL_ACTION_TERMS+HIGH_STAKES_TERMS)
    issues=[]
    if high and not has_due:
        issues.append(JusticeIssue("due-process-1","due_process_gap","high","High-impact legal action is present, but notice/hearing/appeal/reasons safeguards are not visible in the supplied record.", recovery="human legal professional should verify procedure, jurisdictional safeguards, notice, hearing, reasons, and appeal route"))
        return 0.25, issues
    if high and has_due:
        return 0.75, issues
    return 0.6 if has_due else 0.5, issues


def _score_stakeholder_alignment(case: CaseInput) -> Tuple[float,List[JusticeIssue],List[Dict[str,Any]]]:
    issues=[]
    rows=[]
    norm_text_all=" ".join(n.text + " " + n.purpose + " " + " ".join(n.elements) + " " + " ".join(n.safeguards) for n in case.legal_norms)
    for s in case.stakeholders:
        s_text=s.narrative + " " + " ".join(s.goals + s.constraints + s.vulnerabilities + s.perceived_injustice)
        sim=jaccard(tokens(norm_text_all), tokens(s_text))
        gap=1-sim
        rows.append({"stakeholder_id":s.stakeholder_id,"role":s.role,"norm_cognition_similarity":round(sim,4),"semantic_gap":round(gap,4)})
        if sim < 0.08 and (s.goals or s.perceived_injustice):
            issues.append(JusticeIssue(f"cognitive-gap-{s.stakeholder_id}","stakeholder_cognitive_gap","medium",f"Stakeholder {s.stakeholder_id} has goals or perceived injustice weakly connected to the visible legal-norm semantics.", affected_stakeholders=[s.stakeholder_id], recovery="prepare plain-language explanation and identify whether cognition gap reflects missing law, missing facts, mistranslation, or genuine injustice"))
    score=round(sum(r["norm_cognition_similarity"] for r in rows)/max(1,len(rows)),4)
    return min(1.0, score*4), issues, rows


def _score_purpose_alignment(case: CaseInput) -> Tuple[float,List[JusticeIssue]]:
    issues=[]
    legal_purpose=" ".join(n.purpose for n in case.legal_norms)
    proposed=case.proposed_action
    sim=jaccard(tokens(legal_purpose), tokens(proposed)) if legal_purpose and proposed else 0
    if proposed and legal_purpose and sim < 0.05:
        issues.append(JusticeIssue("purpose-gap-1","purpose_misalignment","high","The proposed action is weakly aligned with visible stated legal purposes. Formal legality may not equal semantic justice.", recovery="state the legal purpose, public interest, proportionality rationale, and least-burdensome alternative"))
    if keyword_hit(proposed, ["maximum", "severe", "highest", "最高", "最严", "从重"]) and not keyword_hit(legal_purpose+proposed, EQUITY_TERMS):
        issues.append(JusticeIssue("proportionality-1","proportionality_gap","high","Proposed action appears severe but proportionality/equity semantics are not visible.", recovery="evaluate necessity, proportionality, less restrictive alternatives, and affected party circumstances"))
    return round(max(0.2, min(1.0, sim*5 if sim else 0.45)),4), issues


def _score_equity(case: CaseInput) -> Tuple[float,List[JusticeIssue]]:
    issues=[]
    text=" ".join(case.facts + [case.proposed_action] + [s.narrative + " " + " ".join(s.vulnerabilities) for s in case.stakeholders])
    has_equity=keyword_hit(text, EQUITY_TERMS)
    has_vulnerable=any(s.vulnerabilities for s in case.stakeholders)
    if has_vulnerable and not has_equity:
        issues.append(JusticeIssue("equity-1","equity_context_gap","medium","Stakeholder vulnerabilities are present, but equity/proportionality context is not visibly integrated into reasoning.", affected_stakeholders=[s.stakeholder_id for s in case.stakeholders if s.vulnerabilities], recovery="document vulnerabilities, material impact, proportionality, and mitigation options"))
        return 0.35, issues
    if has_vulnerable and has_equity:
        return 0.75, issues
    return 0.6, issues


def analyze_case(case: CaseInput) -> JusticeReport:
    normative_graph=build_normative_graph(case)
    stakeholder_graph=build_stakeholder_graph(case)
    evidence_score, ev_issues=_score_evidence(case)
    due_score, due_issues=_score_due_process(case)
    stakeholder_score, sh_issues, alignment_rows=_score_stakeholder_alignment(case)
    purpose_score, p_issues=_score_purpose_alignment(case)
    equity_score, eq_issues=_score_equity(case)
    scores={
        "evidence_support":evidence_score,
        "due_process_visibility":due_score,
        "stakeholder_alignment":round(stakeholder_score,4),
        "purpose_alignment":purpose_score,
        "equity_context":equity_score,
    }
    weights={"evidence_support":0.25,"due_process_visibility":0.25,"stakeholder_alignment":0.15,"purpose_alignment":0.2,"equity_context":0.15}
    total=round(sum(scores[k]*weights[k] for k in scores),4)
    issues=ev_issues+due_issues+sh_issues+p_issues+eq_issues
    high=sum(1 for i in issues if i.severity=="high")
    if high or keyword_hit(" ".join(case.facts+[case.proposed_action]), HIGH_STAKES_TERMS):
        decision="human_legal_review_required"
    elif total < 0.55:
        decision="semantic_repair_required"
    else:
        decision="explanation_ready_for_human_review"
    action_boundary=[
        "Non-adjudicative: do not use as verdict, sentencing, deportation, benefit denial, or enforcement engine.",
        "Human legal professional must verify jurisdiction, current law, evidence admissibility, and procedure.",
        "Stakeholder narratives are subjective cognition records, not factual proof unless supported by evidence.",
        "No automatic processing of sensitive legal data without consent, minimization, and access control.",
    ]
    residual=[
        "Jurisdiction-specific legal validity is not independently verified.",
        "Case facts may be incomplete, contested, or strategically framed.",
        "Normative purpose and equity values may conflict across institutions and stakeholders.",
        "The system provides semantic audit, not legal advice or legal outcome prediction.",
    ]
    return JusticeReport(
        system="DIKWP SemanticJustice OS",
        version="0.1.0",
        case_id=case.case_id,
        title=case.title,
        decision=decision,
        semantic_justice_score=total,
        scores=scores,
        issues=issues,
        normative_graph=normative_graph,
        stakeholder_graph=stakeholder_graph,
        alignment_matrix=alignment_rows,
        action_boundary=action_boundary,
        residual=residual,
    )
