from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class LegalNorm:
    norm_id: str
    title: str
    text: str
    source: str = "user_supplied"
    purpose: str = ""
    elements: List[str] = field(default_factory=list)
    safeguards: List[str] = field(default_factory=list)


@dataclass
class EvidenceItem:
    evidence_id: str
    text: str
    source: str = "user_supplied"
    reliability: str = "provisional"
    supports: List[str] = field(default_factory=list)
    contested: bool = False


@dataclass
class Stakeholder:
    stakeholder_id: str
    role: str
    narrative: str
    goals: List[str] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    vulnerabilities: List[str] = field(default_factory=list)
    perceived_injustice: List[str] = field(default_factory=list)


@dataclass
class CaseInput:
    case_id: str
    title: str
    jurisdiction: str = "unspecified"
    case_type: str = "unspecified"
    facts: List[str] = field(default_factory=list)
    legal_norms: List[LegalNorm] = field(default_factory=list)
    evidence: List[EvidenceItem] = field(default_factory=list)
    stakeholders: List[Stakeholder] = field(default_factory=list)
    proposed_action: str = ""
    requested_output: str = "semantic_audit_only"


@dataclass
class DIKWPRecord:
    object_id: str
    object_type: str
    D: List[str] = field(default_factory=list)
    I: List[str] = field(default_factory=list)
    K: List[str] = field(default_factory=list)
    W: List[str] = field(default_factory=list)
    P: List[str] = field(default_factory=list)
    R: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class JusticeIssue:
    issue_id: str
    category: str
    severity: str
    description: str
    affected_stakeholders: List[str] = field(default_factory=list)
    evidence_ids: List[str] = field(default_factory=list)
    recovery: str = "human legal review"


@dataclass
class JusticeReport:
    system: str
    version: str
    case_id: str
    title: str
    decision: str
    semantic_justice_score: float
    scores: Dict[str, float]
    issues: List[JusticeIssue]
    normative_graph: List[DIKWPRecord]
    stakeholder_graph: List[DIKWPRecord]
    alignment_matrix: List[Dict[str, Any]]
    action_boundary: List[str]
    residual: List[str]

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d
