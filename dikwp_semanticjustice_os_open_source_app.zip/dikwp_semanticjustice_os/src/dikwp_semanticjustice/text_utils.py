from __future__ import annotations
import re
from typing import Iterable, List

_WORD_RE = re.compile(r"[A-Za-z0-9_\-]+|[\u4e00-\u9fff]+")


def norm_text(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip())


def tokens(text: str) -> List[str]:
    return [m.group(0).lower() for m in _WORD_RE.finditer(norm_text(text))]


def keyword_hit(text: str, kws: Iterable[str]) -> bool:
    low = norm_text(text).lower()
    return any(k.lower() in low for k in kws)


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    sa, sb = set(a), set(b)
    if not sa and not sb:
        return 0.0
    return len(sa & sb) / max(1, len(sa | sb))


def clip(text: str, n: int = 260) -> str:
    text = norm_text(text)
    return text if len(text) <= n else text[: n - 1] + "…"
