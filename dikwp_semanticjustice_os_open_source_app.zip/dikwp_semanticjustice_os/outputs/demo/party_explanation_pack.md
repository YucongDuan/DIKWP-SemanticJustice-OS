# Plain-Language Semantic Justice Explanation Pack

This pack is not legal advice. It explains what the semantic audit found and what should be reviewed by a human legal professional.

Case: Street vendor administrative penalty dispute
Review status: human_legal_review_required

## What the system checked
- Facts and evidence support.
- Legal rules and stated purposes.
- Stakeholder goals, constraints, and perceived injustice.
- Due process, proportionality, equity, and explanation gaps.

## Main issues
- Stakeholder S3 has goals or perceived injustice weakly connected to the visible legal-norm semantics.
- The proposed action is weakly aligned with visible stated legal purposes. Formal legality may not equal semantic justice.
- Proposed action appears severe but proportionality/equity semantics are not visible.

## What to ask a lawyer or legal aid worker
- Which legal rule applies and is it current?
- What facts are still unsupported or contested?
- Was notice, hearing, reasons, and appeal available?
- Is the proposed action proportional to the public purpose?
- Are there less burdensome alternatives or mitigation options?

## Boundaries
- Non-adjudicative: do not use as verdict, sentencing, deportation, benefit denial, or enforcement engine.
- Human legal professional must verify jurisdiction, current law, evidence admissibility, and procedure.
- Stakeholder narratives are subjective cognition records, not factual proof unless supported by evidence.
- No automatic processing of sensitive legal data without consent, minimization, and access control.
