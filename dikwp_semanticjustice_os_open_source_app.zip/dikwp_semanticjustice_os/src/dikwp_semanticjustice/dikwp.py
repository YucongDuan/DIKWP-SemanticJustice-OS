from __future__ import annotations
from typing import List, Dict
from .models import LegalNorm, EvidenceItem, Stakeholder, CaseInput, DIKWPRecord
from .text_utils import keyword_hit, tokens, clip

DUE_PROCESS_TERMS = ["notice", "hearing", "appeal", "reasons", "procedural", "程序", "听证", "告知", "申诉", "理由", "复议"]
EQUITY_TERMS = ["equity", "fairness", "proportional", "livelihood", "vulnerable", "公平", "比例", "生计", "弱势", "困难"]
PURPOSE_TERMS = ["purpose", "intent", "objective", "policy", "目标", "目的", "意图", "宗旨"]


def norm_to_record(norm: LegalNorm) -> DIKWPRecord:
    return DIKWPRecord(
        object_id=norm.norm_id,
        object_type="legal_norm",
        D=[clip(norm.text), f"source={norm.source}"],
        I=[f"element={e}" for e in norm.elements] + [f"safeguard={s}" for s in norm.safeguards],
        K=[f"norm_title={norm.title}", "legal rule supplied by user or policy pack"],
        W=["due process" if keyword_hit(norm.text + ' ' + ' '.join(norm.safeguards), DUE_PROCESS_TERMS) else "formal legality",
           "proportionality/equity" if keyword_hit(norm.text + ' ' + norm.purpose, EQUITY_TERMS) else "context review required"],
        P=[norm.purpose or "transform legal uncertainty into lawful and fair disposition"],
        R={"reliability":"borrowed_user_or_policy_pack", "support_scope":"normative content only", "kill":"jurisdiction or text invalidated"},
    )


def evidence_to_record(ev: EvidenceItem) -> DIKWPRecord:
    return DIKWPRecord(
        object_id=ev.evidence_id,
        object_type="evidence",
        D=[clip(ev.text), f"source={ev.source}"],
        I=[f"supports={s}" for s in ev.supports] + (["contested"] if ev.contested else []),
        K=["evidence item for claim custody"],
        W=["do not overextend beyond stated support scope"],
        P=["support or contest factual/legal claim"],
        R={"reliability":ev.reliability, "contested":ev.contested, "support_scope":ev.supports, "kill":"source disproven or chain of custody broken"},
    )


def stakeholder_to_record(s: Stakeholder) -> DIKWPRecord:
    return DIKWPRecord(
        object_id=s.stakeholder_id,
        object_type="stakeholder_cognition",
        D=[clip(s.narrative), f"role={s.role}"],
        I=[f"goal={g}" for g in s.goals] + [f"constraint={c}" for c in s.constraints] + [f"vulnerability={v}" for v in s.vulnerabilities],
        K=["stakeholder subjective cognition and contextual semantics"],
        W=s.perceived_injustice or ["perceived fairness unknown"],
        P=[f"desired outcome={g}" for g in s.goals] or ["purpose unknown"],
        R={"reliability":"borrowed_from_party_statement", "support_scope":"subjective cognition; not proof of legal fact", "kill":"contradicted by evidence or corrected by stakeholder"},
    )


def build_normative_graph(case: CaseInput) -> List[DIKWPRecord]:
    records=[norm_to_record(n) for n in case.legal_norms]
    records.extend(evidence_to_record(e) for e in case.evidence)
    if case.facts:
        records.append(DIKWPRecord(
            object_id=f"{case.case_id}:facts",
            object_type="case_facts",
            D=[clip(f) for f in case.facts],
            I=["timeline/actor/action extraction required"],
            K=["case fact base supplied for semantic analysis"],
            W=["facts must not be assumed true without evidence support"],
            P=["transform raw case facts into contestable issue ledger"],
            R={"reliability":"provisional_user_supplied", "kill":"facts disputed or unsupported"},
        ))
    return records


def build_stakeholder_graph(case: CaseInput) -> List[DIKWPRecord]:
    return [stakeholder_to_record(s) for s in case.stakeholders]
