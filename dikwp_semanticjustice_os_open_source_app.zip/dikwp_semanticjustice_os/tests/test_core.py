from pathlib import Path
import json
from dikwp_semanticjustice.analyzer import load_case, analyze_case
from dikwp_semanticjustice.static_audit import audit_path


def test_demo_case_analyzes():
    case=load_case(Path(__file__).parents[1]/"examples"/"sample_admin_case.json")
    report=analyze_case(case)
    assert report.case_id == "admin-demo-001"
    assert report.semantic_justice_score > 0
    assert report.decision in {"human_legal_review_required","semantic_repair_required","explanation_ready_for_human_review"}
    assert len(report.normative_graph) >= 3
    assert len(report.stakeholder_graph) == 3


def test_due_process_or_purpose_issue_detected():
    case=load_case(Path(__file__).parents[1]/"examples"/"sample_admin_case.json")
    report=analyze_case(case)
    categories={i.category for i in report.issues}
    assert "purpose_misalignment" in categories or "proportionality_gap" in categories or "stakeholder_cognitive_gap" in categories


def test_static_audit_passes():
    result=audit_path(Path(__file__).parents[1]/"src")
    assert result["pass"] is True
