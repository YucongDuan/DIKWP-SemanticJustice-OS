# DIKWP Model Mapping for Semantic Justice

## D / Data
Raw legal text, facts, dates, sources, evidence items, party statements.

## I / Information
Differences, legal elements, contested facts, timelines, procedural steps, stakeholder relationships.

## K / Knowledge
Legal norms, statutory elements, precedents, burden of proof, legal doctrines, administrative procedures.

## W / Wisdom
Fairness, due process, proportionality, dignity, equity, vulnerability, public interest, institutional legitimacy.

## P / Purpose
The desired legal transformation: from contested state to lawful, reasoned, explainable, proportionate, and procedurally fair resolution.

## R / Reliability
Source custody, evidence strength, support scope, contested status, time validity, jurisdiction validity, and kill conditions.
