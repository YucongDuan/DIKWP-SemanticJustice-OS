# Architecture

DIKWP SemanticJustice OS uses a non-adjudicative pipeline:

1. **Case intake**: legal norms, facts, evidence, stakeholders, proposed action.
2. **Normative content graph**: norms and evidence are registered as DIKWP records.
3. **Stakeholder cognition graph**: narratives, goals, constraints, vulnerabilities, and perceived injustice are registered as DIKWP records.
4. **DIKWP×DIKWP alignment**: the system compares normative semantics and stakeholder semantics.
5. **Issue detection**: evidence gap, due process gap, purpose misalignment, proportionality gap, stakeholder cognitive gap.
6. **Human-review outputs**: checklist, plain-language explanation, issue queue, ledger exports.

## Why not a verdict engine?

Semantic justice requires more than formal logical correctness. Legal facts may be incomplete, legal norms may conflict, parties may misunderstand law, and a formally legal result may still fail due process, proportionality, or statutory purpose. Therefore the system is deliberately designed as a preparation and audit layer for human review.
