from __future__ import annotations
import csv, json
from pathlib import Path
from typing import Iterable, Dict, Any
from dataclasses import asdict
from .models import JusticeReport


def write_outputs(report: JusticeReport, out_dir: str | Path) -> None:
    out=Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out/"semantic_justice_report.json").write_text(json.dumps(report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_normative_graph.json").write_text(json.dumps([r.to_dict() for r in report.normative_graph], ensure_ascii=False, indent=2), encoding="utf-8")
    (out/"dikwp_stakeholder_graph.json").write_text(json.dumps([r.to_dict() for r in report.stakeholder_graph], ensure_ascii=False, indent=2), encoding="utf-8")
    with (out/"semantic_alignment_matrix.csv").open("w", newline="", encoding="utf-8") as f:
        writer=csv.DictWriter(f, fieldnames=["stakeholder_id","role","norm_cognition_similarity","semantic_gap"])
        writer.writeheader(); writer.writerows(report.alignment_matrix)
    with (out/"justice_issue_queue.csv").open("w", newline="", encoding="utf-8") as f:
        writer=csv.DictWriter(f, fieldnames=["issue_id","category","severity","description","affected_stakeholders","evidence_ids","recovery"])
        writer.writeheader()
        for i in report.issues:
            writer.writerow({
                "issue_id":i.issue_id,
                "category":i.category,
                "severity":i.severity,
                "description":i.description,
                "affected_stakeholders":";".join(i.affected_stakeholders),
                "evidence_ids":";".join(i.evidence_ids),
                "recovery":i.recovery,
            })
    (out/"legal_review_checklist.md").write_text(render_checklist(report), encoding="utf-8")
    (out/"party_explanation_pack.md").write_text(render_party_pack(report), encoding="utf-8")


def render_checklist(report: JusticeReport) -> str:
    lines=[
        "# Legal Review Checklist",
        "",
        f"Case: {report.title} ({report.case_id})",
        f"Decision: {report.decision}",
        f"Semantic Justice Score: {report.semantic_justice_score}",
        "",
        "## Scores",
    ]
    for k,v in report.scores.items():
        lines.append(f"- {k}: {v}")
    lines += ["", "## Issues for human review"]
    if not report.issues:
        lines.append("- No major semantic issue detected, but legal professional review remains required.")
    for i in report.issues:
        lines.append(f"- **{i.severity.upper()} / {i.category}**: {i.description} Recovery: {i.recovery}")
    lines += ["", "## Required checks", "- Verify jurisdiction and current legal text.", "- Verify evidence chain and admissibility.", "- Verify due process: notice, hearing, reasons, appeal, representation.", "- Verify proportionality and less-burdensome alternatives.", "- Verify whether stakeholder cognition gap reflects misunderstanding, missing facts, translation, or actual injustice.", "- Do not issue automated legal decision from this report."]
    return "\n".join(lines)+"\n"


def render_party_pack(report: JusticeReport) -> str:
    lines=[
        "# Plain-Language Semantic Justice Explanation Pack",
        "",
        "This pack is not legal advice. It explains what the semantic audit found and what should be reviewed by a human legal professional.",
        "",
        f"Case: {report.title}",
        f"Review status: {report.decision}",
        "",
        "## What the system checked",
        "- Facts and evidence support.",
        "- Legal rules and stated purposes.",
        "- Stakeholder goals, constraints, and perceived injustice.",
        "- Due process, proportionality, equity, and explanation gaps.",
        "",
        "## Main issues",
    ]
    for i in report.issues[:8]:
        lines.append(f"- {i.description}")
    if not report.issues:
        lines.append("- No major issue was detected, but this remains a preparation tool only.")
    lines += ["", "## What to ask a lawyer or legal aid worker", "- Which legal rule applies and is it current?", "- What facts are still unsupported or contested?", "- Was notice, hearing, reasons, and appeal available?", "- Is the proposed action proportional to the public purpose?", "- Are there less burdensome alternatives or mitigation options?", "", "## Boundaries", *[f"- {b}" for b in report.action_boundary]]
    return "\n".join(lines)+"\n"
